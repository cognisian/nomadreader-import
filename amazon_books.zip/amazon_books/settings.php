<?php
define('AWS_API_KEY', 'AKIAINMQATUGYM2WDFLA');
define('AWS_API_SECRET_KEY', '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');
define('AWS_ASSOCIATE_TAG', 'nomad20-20');

define('AMAZON_BUY_BUTTON_TEXT', 'Buy From Amazon');
